"""Windows desktop controller for the exclusive AutoCAD MCP gateway."""
import json
import os
import queue
import shutil
import socket
import subprocess
import sys
import threading
import time
import tkinter as tk
import urllib.request
import webbrowser
import winreg
import zipfile
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

import agentconfig
import agentnote
import cadweb_local
import dutoan_data
import install_ui
import remote_agent
import knowledge
import litebim_bridge
import knowledge_propose
from logfile import RotatingLog, start_logged
from skillzip import build_skill_zips
from tray import TrayIcon

ROOT = Path(__file__).resolve().parent.parent
SKILLS_SOURCE = ROOT / ".codex" / "skills"
CLAUDE_DESKTOP = "Claude Desktop (tải zip lên)"
LOG_DIR = ROOT / "launcher" / "logs"
SETTINGS_FILE = ROOT / "launcher" / "state" / "settings.json"
REPOS = {
    "puran": ROOT / "puran-water-autocad-mcp",
    "beiming": ROOT / "autocad-beiming-mcp",
}
NAMES = {"puran": "autocad_puran", "beiming": "autocad_beiming"}
UPDATE_REPO = "KenjiIT/autocad-mcp-launcher"
DUTOAN_DIR = ROOT / "du-toan-mcp"
STARTUP_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"
STARTUP_VALUE = "AutoCADMcpLauncher"


def startup_enabled():
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, STARTUP_KEY) as key:
            winreg.QueryValueEx(key, STARTUP_VALUE)
        return True
    except FileNotFoundError:
        return False


def set_startup_enabled(enabled):
    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, STARTUP_KEY, 0,
                        winreg.KEY_SET_VALUE) as key:
        if enabled:
            wscript = Path(os.environ.get("WINDIR", r"C:\Windows")) / "System32" / "wscript.exe"
            launcher = ROOT / "Start AutoCAD MCP.vbs"
            command = f'"{wscript}" "{launcher}"'
            winreg.SetValueEx(key, STARTUP_VALUE, 0, winreg.REG_SZ, command)
        else:
            try:
                winreg.DeleteValue(key, STARTUP_VALUE)
            except FileNotFoundError:
                pass


def load_settings():
    try:
        data = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def save_setting(name, value):
    settings = load_settings()
    settings[name] = value
    SETTINGS_FILE.parent.mkdir(parents=True, exist_ok=True)
    temporary = SETTINGS_FILE.with_suffix(".tmp")
    temporary.write_text(json.dumps(settings, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(SETTINGS_FILE)
    if settings.get("remote_machine_token"):
        # Tệp có token của chế độ agent: chỉ chủ tài khoản đọc được (cố gắng, không bắt buộc).
        remote_agent.restrict_to_owner(SETTINGS_FILE)


def app_version():
    try:
        return (ROOT / "VERSION").read_text(encoding="utf-8").strip()
    except OSError:
        return "0.0.0"


def python_in(repo):
    return repo / ".venv" / "Scripts" / "python.exe"


def listening(port):
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=0.2):
            return True
    except OSError:
        return False


def block_library_dir():
    """Folder block.insert reads library files from; keep in step with lt_file_ipc."""
    configured = os.environ.get("AUTOCAD_MCP_BLOCK_LIBRARY", "").strip()
    return Path(configured) if configured else ROOT / "blocks"


def listener_pid(port):
    """PID that listens on the loopback ``port``, or None."""
    try:
        output = subprocess.run(["netstat", "-ano", "-p", "tcp"], capture_output=True, text=True,
                                timeout=10, creationflags=subprocess.CREATE_NO_WINDOW).stdout
    except (OSError, subprocess.SubprocessError):
        return None
    for line in output.splitlines():
        fields = line.split()
        if len(fields) >= 5 and fields[3] == "LISTENING" and fields[1] == f"127.0.0.1:{port}":
            try:
                return int(fields[4])
            except ValueError:
                return None
    return None


def is_launcher_gateway(port=8764):
    """True when the listener on ``port`` answers /status like this launcher's gateway."""
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/status", timeout=2) as response:
            state = json.load(response)
    except (OSError, ValueError):
        return False
    return isinstance(state, dict) and {"mode", "queued_requests"} <= state.keys()


class AdoptedGateway:
    """A gateway left running by an earlier launcher; the app reuses and later stops it."""

    def __init__(self, pid, port=8764):
        self.pid = pid
        self.port = port

    def poll(self):
        return None if listening(self.port) else 0

    def wait(self, timeout=None):
        deadline = time.time() + (timeout if timeout is not None else 5)
        while listening(self.port) and time.time() < deadline:
            time.sleep(0.1)


def kill_tree(process):
    if process and process.poll() is None:
        subprocess.run(["taskkill", "/PID", str(process.pid), "/T", "/F"],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                       creationflags=subprocess.CREATE_NO_WINDOW)
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            pass


def agent_context():
    """Đường dẫn và lựa chọn của máy này, dùng cho cấu hình agent (xem agentconfig.py)."""
    return agentconfig.Context(
        backup_dir=ROOT / "launcher" / "state" / "config-backups",
        bridge_python=str(python_in(REPOS["puran"])),
        bridge_script=str(ROOT / "launcher" / "stdio_bridge.py"),
        # dutoan cũng qua gateway (HTTP) nhưng không dùng AutoCAD.
        dutoan=(DUTOAN_DIR / "src" / "dutoan_mcp" / "server.py").is_file(),
        litebim=litebim_bridge.installed("litebim"),
        litecad=litebim_bridge.installed("litecad"))


def config_for(agent):
    return agentconfig.snippet(agent, agent_context())

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("AutoCAD MCP Launcher")
        self.geometry("760x700")
        self.minsize(650, 620)
        self.gateway = None
        self.log = None
        self.events = queue.Queue()
        self.busy = False
        self.closing = False
        self.updating = False
        self.update_archive = None
        self.update_wait_started = None
        self.update_busy_notice_shown = False
        self.agent = tk.StringVar(value="OpenAI Codex")
        self.startup_var = tk.BooleanVar(value=startup_enabled())
        self.autostart_mcp_var = tk.BooleanVar(value=bool(load_settings().get("autostart_mcp")))
        self.skill_gate_var = tk.BooleanVar(value=load_settings().get("skill_gate", True) is not False)
        saved = load_settings()
        self.remote_enabled_var = tk.BooleanVar(value=saved.get("remote_agent_enabled") is True)
        self.remote_url_var = tk.StringVar(value=str(saved.get("remote_server_url") or ""))
        self.remote_id_var = tk.StringVar(value=str(saved.get("remote_machine_id") or ""))
        self.remote_token_var = tk.StringVar(value="")  # không bao giờ điền lại token đã lưu
        self.status = tk.StringVar(value="Sẵn sàng")
        self.knowledge_checking = False
        self.knowledge_auto_var = tk.BooleanVar(value=load_settings().get("knowledge_auto_update", True) is not False)
        self.dutoan_auto_var = tk.BooleanVar(value=load_settings().get("dutoan_auto_update", True) is not False)
        self.dutoan_busy = False
        self.cadweb = cadweb_local.CadWebLocal(ROOT, LOG_DIR)
        self.cadweb_auto_var = tk.BooleanVar(value=load_settings().get("cadweb_local_auto", True) is not False)
        self.cadweb_busy = False
        self.build()
        self.refresh_knowledge_status()
        self.refresh_config()
        self.tray_menu = tk.Menu(self, tearoff=False)
        self.tray_menu.add_command(label="Mở ứng dụng", command=self.restore)
        self.tray_menu.add_separator()
        self.tray_menu.add_command(label="Thoát hẳn", command=self.close)
        try:
            self.tray = TrayIcon(self, self.restore, self.show_tray_menu)
        except OSError:
            self.tray = None
        self.bind("<Unmap>", self.on_unmap)
        self.after(500, self.tick)
        self.after(1600, self.check_for_updates)
        self.after(4000, self.knowledge_tick)
        self.after(9000, self.dutoan_tick)
        self.protocol("WM_DELETE_WINDOW", self.hide_to_tray)
        if "--start" in sys.argv[1:] or self.autostart_mcp_var.get():
            self.after(300, self.start)

    def build(self):
        pages = ttk.Notebook(self)
        pages.pack(fill="both", expand=True, padx=12, pady=12)
        main = ttk.Frame(pages, padding=18)
        settings_page = ttk.Frame(pages)
        settings = self.scrollable(settings_page)
        pages.add(main, text="Điều khiển")
        pages.add(settings_page, text="Cài đặt")
        self.build_settings(settings)
        ttk.Label(main, text="AutoCAD MCP", font=("Segoe UI", 20, "bold")).pack(anchor="w")
        ttk.Label(main, text=f"Phiên bản {app_version()}", foreground="#65736f").pack(anchor="w", pady=(0, 5))
        ttk.Label(main, text="Agent ưu tiên AutoCAD; nếu AutoCAD không chạy, agent sẽ hỏi trước khi dùng DXF.",
                  wraplength=690).pack(anchor="w", pady=(2, 18))
        self.start_btn = ttk.Button(main, text="▶  Bật kết nối cho agent", command=self.start)
        self.start_btn.pack(anchor="w")
        self.stop_btn = ttk.Button(main, text="■  Dừng", command=self.stop)
        self.stop_btn.pack(anchor="w", pady=(7, 14))
        self.labels = {}
        for key in REPOS:
            label = ttk.Label(main, text=f"○  {NAMES[key]}  ·  Chưa khởi chạy")
            label.pack(anchor="w", pady=3)
            self.labels[key] = label
        dutoan_status = ("●  dutoan  ·  Sẵn sàng (HTTP qua gateway)" if dutoan_data.describe()["present"]
                         else "○  dutoan  ·  Chưa có dữ liệu (xem Cài đặt, mục Dữ liệu dự toán)")
        self.dutoan_label = ttk.Label(main, text=dutoan_status)
        self.dutoan_label.pack(anchor="w", pady=3)
        self.cadweb_row = None
        if cadweb_local.project_dir(ROOT):   # chỉ hiện nếu máy này có clone cad-web-local cạnh mcp/
            self.cadweb_row = ttk.Frame(main)
            self.cadweb_row.pack(anchor="w", pady=3, fill="x")
            self.cadweb_label = ttk.Label(self.cadweb_row, text="○  CAD Studio (local)  ·  Chưa mở")
            self.cadweb_label.pack(side="left")
            self.cadweb_open_btn = ttk.Button(self.cadweb_row, text="Mở CAD Studio (local)", command=self.open_cadweb_local)
            self.cadweb_open_btn.pack(side="left", padx=(10, 0))
        self.pipe_labels = {}
        for key in ("litebim", "litecad"):
            if litebim_bridge.installed(key):  # chỉ hiện sản phẩm có cài trên máy này
                title = litebim_bridge.PRODUCTS[key][0]
                label = ttk.Label(main, text=f"○  {title}  ·  Chưa kiểm tra")
                label.pack(anchor="w", pady=3)
                self.pipe_labels[key] = label
        ttk.Label(main, textvariable=self.status, foreground="#225c53",
                  wraplength=690).pack(anchor="w", pady=(11, 16))
        row = ttk.Frame(main)
        row.pack(fill="x")
        ttk.Label(row, text="Agent:").pack(side="left")
        agents = ttk.Combobox(row, textvariable=self.agent, state="readonly", width=21,
                              values=agentconfig.AGENTS)
        agents.pack(side="left", padx=10)
        agents.bind("<<ComboboxSelected>>", lambda _: self.refresh_config())
        ttk.Button(row, text="Sao chép cấu hình", command=self.copy).pack(side="right")
        actions = ttk.Frame(main)
        actions.pack(fill="x", pady=(8, 0))
        self.auto_btn = ttk.Button(actions, text="Tự thêm vào agent", command=self.auto_configure)
        self.auto_btn.pack(side="left")
        self.unauto_btn = ttk.Button(actions, text="Gỡ khỏi agent", command=lambda: self.auto_configure(remove=True))
        self.unauto_btn.pack(side="left", padx=8)
        self.agentcfg_status = ttk.Label(main, text="", wraplength=690, justify="left", foreground="#225c53")
        self.agentcfg_status.pack(fill="x", pady=(6, 0))
        self.hint = ttk.Label(main, wraplength=690, justify="left")
        self.hint.pack(fill="x", pady=(10, 7))
        self.config_box = tk.Text(main, height=9, wrap="none", font=("Consolas", 10),
                                  bg="#ffffff", fg="#1b2926", relief="flat", padx=12, pady=12)
        self.config_box.pack(fill="both", expand=True)

    def scrollable(self, page):
        """Return a padded frame inside ``page`` that scrolls when it grows taller than the window."""
        canvas = tk.Canvas(page, highlightthickness=0, borderwidth=0)
        bar = ttk.Scrollbar(page, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=bar.set)
        bar.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)
        inner = ttk.Frame(canvas, padding=24)
        window = canvas.create_window((0, 0), window=inner, anchor="nw")
        inner.bind("<Configure>", lambda _: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda event: canvas.itemconfigure(window, width=event.width))

        def wheel(event):
            if isinstance(event.widget, tk.Listbox):
                return
            if inner.winfo_reqheight() > canvas.winfo_height():
                canvas.yview_scroll(-1 if event.delta > 0 else 1, "units")

        canvas.bind("<Enter>", lambda _: canvas.bind_all("<MouseWheel>", wheel))
        canvas.bind("<Leave>", lambda _: canvas.unbind_all("<MouseWheel>"))
        return inner

    def build_settings(self, frame):
        ttk.Label(frame, text="Cài đặt", font=("Segoe UI", 18, "bold")).pack(anchor="w")
        ttk.Label(frame, text="Tùy chỉnh cách AutoCAD MCP Launcher hoạt động trên máy này.",
                  wraplength=650).pack(anchor="w", pady=(6, 22))
        ttk.Checkbutton(frame, text="Khởi động AutoCAD MCP Launcher cùng Windows",
                        variable=self.startup_var,
                        command=self.save_startup_setting).pack(anchor="w")
        ttk.Label(frame,
                  text="Khi bật, launcher sẽ mở sau khi bạn đăng nhập Windows. Bạn có thể tắt lựa chọn này bất cứ lúc nào.",
                  foreground="#65736f", wraplength=650, justify="left").pack(anchor="w", padx=(24, 0), pady=(6, 12))
        ttk.Checkbutton(frame, text="Tự bật MCP khi mở launcher",
                        variable=self.autostart_mcp_var,
                        command=self.save_autostart_mcp_setting).pack(anchor="w", pady=(4, 0))
        ttk.Label(frame,
                  text="Khi bật, gateway MCP tự chạy ngay khi launcher mở, không cần bấm Bắt đầu. AutoCAD vẫn chỉ được kết nối khi agent gọi tool.",
                  foreground="#65736f", wraplength=650, justify="left").pack(anchor="w", padx=(24, 0), pady=(6, 12))
        ttk.Checkbutton(frame, text="Buộc agent đọc skill điều phối trước khi dùng tool CAD",
                        variable=self.skill_gate_var,
                        command=self.save_skill_gate_setting).pack(anchor="w", pady=(4, 0))
        ttk.Label(frame,
                  text="Khi bật (khuyên bật), gateway từ chối tool CAD cho tới khi phiên agent đã đọc skill autocad-agent-coordinator qua tool skills; lời từ chối nói rõ phải làm gì. Có hiệu lực ngay, không cần mở lại launcher. Các tool skills, knowledge, knowledge_propose và dutoan không bị chặn.",
                  foreground="#65736f", wraplength=650, justify="left").pack(anchor="w", padx=(24, 0), pady=(6, 12))
        self.settings_status = ttk.Label(frame, text="")
        self.settings_status.pack(anchor="w", padx=(24, 0))
        ttk.Separator(frame).pack(fill="x", pady=12)
        ttk.Label(frame, text="Tri thức AutoCAD", font=("Segoe UI", 13, "bold")).pack(anchor="w")
        ttk.Label(frame,
                  text="Tải các trang tri thức công khai (cách đọc bản vẽ, bóc khối lượng, lỗi hay gặp) về máy. Launcher chỉ nhận bản phát hành đã được người duyệt đóng tag, kiểm tra SHA-256, và kiểm tra bản mới mỗi 24 giờ. Trang nào bản mới không còn sẽ bị xóa khỏi wiki/; thư mục proposals/ và sensitive-terms.local.txt không bị đụng. Nút bên phải tải lại ngay. Chỉ tải về, không tải lên gì. Việc gửi đề xuất do agent làm bằng tool knowledge_propose, ở mục bên dưới.",
                  foreground="#65736f", wraplength=650, justify="left").pack(anchor="w", pady=(5, 6))
        ttk.Checkbutton(frame, text="Tự kiểm tra và cập nhật tri thức mỗi 24 giờ",
                        variable=self.knowledge_auto_var,
                        command=self.save_knowledge_auto_setting).pack(anchor="w", pady=(0, 6))
        self.knowledge_dir_var = tk.StringVar(value=self.knowledge_dir())
        knowledge_row = ttk.Frame(frame)
        knowledge_row.pack(fill="x")
        ttk.Entry(knowledge_row, textvariable=self.knowledge_dir_var, state="readonly").pack(
            side="left", fill="x", expand=True)
        ttk.Button(knowledge_row, text="Đổi thư mục…", command=self.choose_knowledge_dir).pack(side="left", padx=(6, 0))
        self.knowledge_btn = ttk.Button(knowledge_row, text="Tải tri thức", command=lambda: self.run_knowledge_check(force=True))
        self.knowledge_btn.pack(side="left", padx=(6, 0))
        self.knowledge_status = ttk.Label(frame, text="")
        self.knowledge_status.pack(anchor="w", pady=(6, 0))
        ttk.Label(frame, text="Gửi đề xuất tri thức", font=("Segoe UI", 11, "bold")).pack(anchor="w", pady=(12, 0))
        ttk.Label(frame,
                  text="Agent gửi trang đề xuất (đã gỡ tên dự án, số liệu thật) vào hàng chờ duyệt; chỉ sau khi người duyệt chấp nhận mới công khai. Khóa nhóm đã có sẵn trong launcher (bản phát hành chính thức). Nội dung được kiểm tra trên máy trước khi gửi: email, số điện thoại, đường dẫn máy, khóa và các thuật ngữ trong sensitive-terms.local.txt (đặt trong thư mục tri thức) sẽ bị chặn. Bản tự dựng không có khóa sẽ hiện thêm ô nhập; khóa nhập tay lưu trong launcher/state/settings.json.",
                  foreground="#65736f", wraplength=650, justify="left").pack(anchor="w", pady=(4, 6))
        settings_now = knowledge_propose.load_settings()
        self.propose_url_var = tk.StringVar(value=knowledge_propose.gateway_url(settings_now))
        self.propose_key_var = tk.StringVar(value=str(settings_now.get("knowledge_team_key") or ""))
        # A key shipped in the package is never shown or editable; the field appears only when none is embedded.
        has_embedded_key = bool(knowledge_propose.embedded_key())
        fields = [("Địa chỉ cổng", self.propose_url_var, False)]
        if not has_embedded_key:
            fields.append(("Khóa nhóm", self.propose_key_var, True))
        for caption, variable, hidden in fields:
            row = ttk.Frame(frame)
            row.pack(fill="x", pady=2)
            ttk.Label(row, text=caption, width=14).pack(side="left")
            ttk.Entry(row, textvariable=variable, show="•" if hidden else "").pack(side="left", fill="x", expand=True)
        if has_embedded_key:
            ttk.Label(frame, text="Khóa nhóm đã được tích hợp sẵn trong launcher; không cần nhập.",
                      foreground="#225c53").pack(anchor="w", pady=(2, 0))
        ttk.Button(frame, text="Lưu cấu hình gửi đề xuất", command=self.save_propose_settings).pack(
            anchor="w", pady=(6, 0))
        self.propose_status = ttk.Label(frame, text="")
        self.propose_status.pack(anchor="w", pady=(6, 0))
        ttk.Separator(frame).pack(fill="x", pady=12)
        ttk.Label(frame, text="Dữ liệu dự toán", font=("Segoe UI", 13, "bold")).pack(anchor="w")
        ttk.Label(frame,
                  text="Công cụ dutoan cần tệp dutoan.db (đơn giá, định mức). Tệp này không đi kèm launcher và không được đưa lên chỗ công khai. Nhập khóa dữ liệu do người quản lý cấp (khóa riêng, không nhúng sẵn trong launcher), launcher sẽ tự tải và cập nhật tệp từ cổng của nhóm; tệp được kiểm tra (SHA-256, đủ bảng) rồi mới thay bản cũ. Cách đơn giản nhất: bấm Nhập từ tệp và chọn tệp dutoan.db (hoặc zip chứa nó) do người quản lý gửi. Nếu có cổng nhóm hoặc địa chỉ tải riêng thì dùng các ô bên dưới.",
                  foreground="#65736f", wraplength=650, justify="left").pack(anchor="w", pady=(5, 6))
        settings_dutoan = knowledge_propose.load_settings()
        self.dutoan_url_var = tk.StringVar(value=str(settings_dutoan.get("dutoan_db_url") or ""))
        self.dutoan_sha_var = tk.StringVar(value=str(settings_dutoan.get("dutoan_db_sha256") or ""))
        self.dutoan_key_var = tk.StringVar(value=str(settings_dutoan.get("dutoan_data_key") or ""))
        for caption, variable, hidden in (("Khóa dữ liệu", self.dutoan_key_var, True), ("Địa chỉ tải", self.dutoan_url_var, False),
                                          ("SHA-256", self.dutoan_sha_var, False)):
            row = ttk.Frame(frame)
            row.pack(fill="x", pady=2)
            ttk.Label(row, text=caption, width=14).pack(side="left")
            ttk.Entry(row, textvariable=variable, show="•" if hidden else "").pack(side="left", fill="x", expand=True)
        buttons = ttk.Frame(frame)
        buttons.pack(anchor="w", pady=(6, 0))
        self.dutoan_sync_button = ttk.Button(buttons, text="Cập nhật từ cổng nhóm", command=lambda: self.run_dutoan_sync(manual=True))
        self.dutoan_sync_button.pack(side="left")
        self.dutoan_button = ttk.Button(buttons, text="Tải theo địa chỉ", command=self.run_dutoan_download)
        self.dutoan_button.pack(side="left", padx=(8, 0))
        ttk.Button(buttons, text="Nhập từ tệp…", command=self.import_dutoan_file).pack(side="left", padx=(8, 0))
        ttk.Button(buttons, text="Mở thư mục dữ liệu", command=self.open_dutoan_folder).pack(side="left", padx=(8, 0))
        self.dutoan_status = ttk.Label(frame, text=dutoan_data.describe()["message"])
        self.dutoan_status.pack(anchor="w", pady=(6, 0))
        ttk.Checkbutton(frame, text="Tự cập nhật dữ liệu dự toán từ cổng nhóm khi mở launcher",
                        variable=self.dutoan_auto_var, command=self.save_dutoan_auto_setting).pack(anchor="w", pady=(4, 0))
        if cadweb_local.project_dir(ROOT):   # chỉ hiện nếu máy này có clone cad-web-local cạnh mcp/
            ttk.Separator(frame).pack(fill="x", pady=12)
            ttk.Label(frame, text="CAD Studio (local)", font=("Segoe UI", 13, "bold")).pack(anchor="w")
            ttk.Label(frame,
                      text="Web chat gọi MCP ngay trên máy này (không đăng nhập, không máy CAD từ xa) — chạy ngay trong launcher, không cần cài thêm.",
                      foreground="#65736f", wraplength=650, justify="left").pack(anchor="w", pady=(5, 6))
            ttk.Checkbutton(frame, text="Tự mở CAD Studio (local) khi bật kết nối cho agent",
                            variable=self.cadweb_auto_var, command=self.save_cadweb_auto_setting).pack(anchor="w", pady=(4, 0))
        ttk.Separator(frame).pack(fill="x", pady=12)
        ttk.Label(frame, text="Kết nối ra server (agent từ xa)", font=("Segoe UI", 13, "bold")).pack(anchor="w")
        ttk.Label(frame,
                  text="Dùng khi web hoặc server nằm ở máy khác: launcher chủ động kết nối ra server (wss://), server gọi MCP của máy này qua kết nối đó. Không mở cổng nào ở máy này. Tắt mặc định; tắt thì mọi thứ chạy như cũ. Token là bí mật và sẽ không hiện lại sau khi lưu. Tool launcher_set_backend bị chặn với server. Cần gateway đang chạy (Bật kết nối cho agent); máy dùng lâu dài nên bật Tự bật MCP khi mở launcher.",
                  foreground="#65736f", wraplength=650, justify="left").pack(anchor="w", pady=(5, 6))
        ttk.Checkbutton(frame, text="Bật kết nối ra server", variable=self.remote_enabled_var).pack(anchor="w", pady=(0, 4))
        for caption, variable, hidden in (("Địa chỉ server", self.remote_url_var, False), ("Mã máy", self.remote_id_var, False),
                                          ("Token", self.remote_token_var, True)):
            row = ttk.Frame(frame)
            row.pack(fill="x", pady=2)
            ttk.Label(row, text=caption, width=14).pack(side="left")
            ttk.Entry(row, textvariable=variable, show="•" if hidden else "").pack(side="left", fill="x", expand=True)
        self.remote_token_note = ttk.Label(frame, text="", foreground="#65736f")
        self.remote_token_note.pack(anchor="w", pady=(2, 0))
        self.refresh_remote_token_note()
        ttk.Button(frame, text="Lưu cấu hình kết nối ra server", command=self.save_remote_settings).pack(anchor="w", pady=(6, 0))
        self.remote_status = ttk.Label(frame, text="", wraplength=650, justify="left")
        self.remote_status.pack(anchor="w", pady=(6, 0))
        self.remote_live = ttk.Label(frame, text="Trạng thái: đang tắt.", foreground="#225c53", wraplength=650, justify="left")
        self.remote_live.pack(anchor="w", pady=(2, 0))
        ttk.Separator(frame).pack(fill="x", pady=12)
        ttk.Label(frame, text="Thư viện block", font=("Segoe UI", 13, "bold")).pack(anchor="w")
        ttk.Label(frame,
                  text="Nơi lưu các block dựng sẵn (nội thất, cây cối, thiết bị vệ sinh) dạng .dwg hoặc .dxf. Agent chèn chúng bằng tên file; đơn vị mỗi file phải là mm. Thư mục con có file index.json là một kho riêng (ví dụ dwgshare), agent tra theo loại và kích thước. Quy ước đặt tên có trong README.md của thư mục.",
                  foreground="#65736f", wraplength=650, justify="left").pack(anchor="w", pady=(5, 6))
        library_row = ttk.Frame(frame)
        library_row.pack(fill="x")
        self.block_library_var = tk.StringVar(value=str(block_library_dir()))
        ttk.Entry(library_row, textvariable=self.block_library_var, state="readonly").pack(
            side="left", fill="x", expand=True)
        ttk.Button(library_row, text="Mở thư mục thư viện", command=self.open_block_library).pack(
            side="left", padx=(6, 0))
        self.block_library_status = ttk.Label(frame, text=self.block_library_summary())
        self.block_library_status.pack(anchor="w", pady=(6, 0))
        ttk.Separator(frame).pack(fill="x", pady=12)
        ttk.Label(frame, text="Cài skill cho agent", font=("Segoe UI", 13, "bold")).pack(anchor="w")
        ttk.Label(frame,
                  text="Chọn agent và các skill AutoCAD muốn cài hoặc cập nhật. Skill được chép vào thư mục dùng chung của tài khoản Windows.",
                  foreground="#65736f", wraplength=650, justify="left").pack(anchor="w", pady=(5, 10))
        self.skill_agent = tk.StringVar(value="OpenAI Codex")
        self.skill_agents = {
            "OpenAI Codex": Path.home() / ".codex" / "skills",
            "Claude Code": Path.home() / ".claude" / "skills",
            CLAUDE_DESKTOP: Path.home() / "AutoCAD-MCP-Skills-Claude-Desktop",
        }
        self.agent_notes = {
            "OpenAI Codex": Path.home() / ".codex" / "AGENTS.md",
            "Claude Code": Path.home() / ".claude" / "CLAUDE.md",
        }
        ttk.Combobox(frame, textvariable=self.skill_agent, state="readonly", width=24,
                     values=tuple(self.skill_agents)).pack(anchor="w", pady=(0, 8))
        list_frame = ttk.Frame(frame)
        list_frame.pack(fill="both", expand=True)
        self.skill_list = tk.Listbox(list_frame, selectmode="extended", height=8,
                                     exportselection=False, font=("Segoe UI", 9))
        scrollbar = ttk.Scrollbar(list_frame, orient="vertical", command=self.skill_list.yview)
        self.skill_list.configure(yscrollcommand=scrollbar.set)
        self.skill_list.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        self.skill_names = self.available_skills()
        for name in self.skill_names:
            self.skill_list.insert("end", name)
        skill_actions = ttk.Frame(frame)
        skill_actions.pack(fill="x", pady=(8, 0))
        ttk.Button(skill_actions, text="Chọn tất cả", command=self.select_all_skills).pack(side="left")
        ttk.Button(skill_actions, text="Cài / cập nhật skill đã chọn",
                   command=self.install_selected_skills).pack(side="right")
        self.skill_status = ttk.Label(frame, text=f"Có {len(self.skill_names)} skill trong bản này.",
                                      foreground="#225c53")
        self.skill_status.pack(anchor="w", pady=(8, 0))

    @staticmethod
    def available_skills():
        skills_dir = SKILLS_SOURCE
        return sorted(path.name for path in skills_dir.iterdir()
                      if path.is_dir() and (path / "SKILL.md").is_file()) if skills_dir.is_dir() else []

    @staticmethod
    def missing_skills():
        """Skills that the other agent folders carry but the installer source lacks."""
        names = set(App.available_skills())
        extra = set()
        for folder in (".claude", ".agents"):
            root = ROOT / folder / "skills"
            if root.is_dir():
                extra |= {p.name for p in root.iterdir() if (p / "SKILL.md").is_file()}
        return sorted(extra - names)

    def select_all_skills(self):
        self.skill_list.selection_set(0, "end")

    def install_selected_skills(self):
        selected = [self.skill_names[index] for index in self.skill_list.curselection()]
        if not selected:
            self.skill_status.configure(text="Hãy chọn ít nhất một skill.", foreground="#9a5b00")
            return
        target_root = self.skill_agents[self.skill_agent.get()]
        source_root = SKILLS_SOURCE
        if self.skill_agent.get() == CLAUDE_DESKTOP:
            self.package_skills_for_claude_desktop(selected, target_root)
            return
        missing = self.missing_skills()
        if missing:
            self.skill_status.configure(
                text=f"Nguồn skill thiếu: {', '.join(missing)}. Đồng bộ {SKILLS_SOURCE} trước khi cài.",
                foreground="#a12622")
            return
        try:
            target_root.mkdir(parents=True, exist_ok=True)
            for name in selected:
                source = source_root / name
                target = target_root / name
                if not (source / "SKILL.md").is_file():
                    raise FileNotFoundError(f"Không tìm thấy nội dung skill: {source}")
                shutil.copytree(source, target, dirs_exist_ok=True)
            note_path = self.agent_notes.get(self.skill_agent.get())
            if note_path:
                agentnote.install_note(note_path)
            self.skill_status.configure(
                text=f"Đã cài / cập nhật {len(selected)} skill cho {self.skill_agent.get()} tại {target_root}."
                     + (f" Đã ghi chỉ dẫn tự dùng skill vào {note_path}." if note_path else ""),
                foreground="#225c53")
        except OSError as exc:
            self.skill_status.configure(text=f"Không cài được skill: {exc}", foreground="#a12622")

    def package_skills_for_claude_desktop(self, selected, target_dir):
        """Claude Desktop keeps its own skill store and only accepts uploaded zips."""
        try:
            build_skill_zips(SKILLS_SOURCE, selected, target_dir)
            os.startfile(str(target_dir))
        except OSError as exc:
            self.skill_status.configure(text=f"Không tạo được file zip: {exc}", foreground="#a12622")
            return
        self.skill_status.configure(
            text=f"Đã tạo {len(selected)} file zip tại {target_dir}. Trong Claude Desktop: Customize, Skills, "
                 "tải từng file lên (xem HUONG-DAN.txt).",
            foreground="#225c53")

    def save_startup_setting(self):
        enabled = self.startup_var.get()
        try:
            set_startup_enabled(enabled)
            self.settings_status.configure(
                text="Đã bật khởi động cùng Windows." if enabled else "Đã tắt khởi động cùng Windows."
            )
        except OSError as exc:
            self.startup_var.set(not enabled)
            self.settings_status.configure(text=f"Không lưu được cài đặt: {exc}")

    def save_autostart_mcp_setting(self):
        enabled = self.autostart_mcp_var.get()
        try:
            save_setting("autostart_mcp", enabled)
            self.settings_status.configure(
                text="Đã bật tự chạy MCP khi mở launcher." if enabled else "Đã tắt tự chạy MCP khi mở launcher."
            )
        except OSError as exc:
            self.autostart_mcp_var.set(not enabled)
            self.settings_status.configure(text=f"Không lưu được cài đặt: {exc}")

    def refresh_remote_token_note(self):
        saved = bool(load_settings().get("remote_machine_token"))
        self.remote_token_note.configure(
            text="Token đã lưu (ẩn). Để trống ô Token nếu không muốn đổi." if saved else "Chưa có token.")

    def save_remote_settings(self):
        enabled = self.remote_enabled_var.get()
        entered = self.remote_token_var.get().strip()
        values = {
            "remote_agent_enabled": enabled,
            "remote_server_url": self.remote_url_var.get().strip(),
            "remote_machine_id": self.remote_id_var.get().strip(),
            "remote_machine_token": entered or str(load_settings().get("remote_machine_token") or ""),
        }
        problem = remote_agent.read_config(values).problem if enabled else ""
        if problem:
            self.remote_status.configure(text=problem, foreground="#a12622")
            return
        try:
            for name, value in values.items():
                save_setting(name, value)
        except OSError as exc:
            self.remote_status.configure(text=f"Không lưu được cài đặt: {exc}", foreground="#a12622")
            return
        self.remote_token_var.set("")
        self.refresh_remote_token_note()
        self.remote_status.configure(
            text="Đã lưu. Gateway nhận cấu hình trong vài giây." if enabled else "Đã lưu; kết nối ra server đang tắt.",
            foreground="#225c53")
        if enabled:
            self.ensure_remote_deps()

    def ensure_remote_deps(self):
        """Cài thư viện websockets vào môi trường của gateway khi bật lần đầu (chỉ khi thiếu)."""
        self.remote_install = {"result": None}

        def worker():
            repo = REPOS["puran"]
            try:
                if install_ui.installed(repo, "import websockets"):
                    self.remote_install["result"] = (True, "")
                    return
                done = subprocess.run([str(python_in(repo)), "-m", "pip", "install", "websockets>=13"],
                                      capture_output=True, text=True, timeout=300,
                                      creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                tail = (done.stdout + done.stderr).strip().splitlines()[-1:] or [""]
                self.remote_install["result"] = (done.returncode == 0, tail[0])
            except Exception as exc:
                self.remote_install["result"] = (False, str(exc))

        threading.Thread(target=worker, daemon=True).start()
        self.after(500, self.poll_remote_install)

    def poll_remote_install(self):
        result = self.remote_install["result"]
        if result is None:
            self.after(500, self.poll_remote_install)
            return
        ok, detail = result
        if not ok:
            self.remote_status.configure(text=f"Không cài được thư viện websockets: {detail}", foreground="#a12622")

    def save_skill_gate_setting(self):
        enabled = self.skill_gate_var.get()
        try:
            save_setting("skill_gate", enabled)
            self.settings_status.configure(
                text="Đã bật: tool CAD chỉ chạy sau khi agent đọc skill điều phối." if enabled
                else "Đã tắt: gateway không còn chặn tool CAD khi chưa đọc skill."
            )
        except OSError as exc:
            self.skill_gate_var.set(not enabled)
            self.settings_status.configure(text=f"Không lưu được cài đặt: {exc}")

    @staticmethod
    def knowledge_dir():
        saved = load_settings().get("knowledge_dir")
        return saved if isinstance(saved, str) and saved else str(Path.home() / "autocad-knowledge")

    @staticmethod
    def block_library_summary():
        folder = block_library_dir()
        try:
            count = sum(1 for path in folder.iterdir() if path.suffix.lower() in (".dwg", ".dxf"))
            stores = sorted(path for path in folder.iterdir()
                            if path.is_dir() and not path.name.startswith(".") and (path / "index.json").is_file())
        except OSError:
            return "Thư mục chưa có; sẽ được tạo khi bạn mở."
        text = f"Hiện có {count} tệp block (.dwg/.dxf)."
        for store in stores:
            try:
                in_store = sum(1 for path in store.iterdir() if path.suffix.lower() in (".dwg", ".dxf"))
            except OSError:
                continue
            text += f" Kho riêng \"{store.name}\": {in_store} tệp."
        return text

    def open_block_library(self):
        folder = block_library_dir()
        try:
            folder.mkdir(parents=True, exist_ok=True)
            os.startfile(str(folder))
        except OSError as exc:
            self.block_library_status.configure(text=f"Không mở được thư mục: {exc}", foreground="#a12622")
            return
        self.block_library_status.configure(text=self.block_library_summary(), foreground="#225c53")

    def choose_knowledge_dir(self):
        chosen = filedialog.askdirectory(initialdir=self.knowledge_dir_var.get(), parent=self,
                                         title="Chọn thư mục lưu tri thức")
        if not chosen:
            return
        chosen = str(Path(chosen))
        try:
            save_setting("knowledge_dir", chosen)
        except OSError as exc:
            self.knowledge_status.configure(text=f"Không lưu được thư mục: {exc}", foreground="#a12622")
            return
        self.knowledge_dir_var.set(chosen)
        self.refresh_knowledge_status()
        if self.knowledge_auto_var.get():
            self.run_knowledge_check(force=False)

    def run_dutoan_download(self):
        if self.dutoan_busy:
            return
        url = self.dutoan_url_var.get().strip()
        sha = self.dutoan_sha_var.get().strip()
        if not url:
            self.dutoan_status.configure(text="Chưa có địa chỉ tải. Hãy dán địa chỉ do người quản lý cấp.", foreground="#a12622")
            return
        try:
            save_setting("dutoan_db_url", url)
            save_setting("dutoan_db_sha256", sha)
        except OSError as exc:
            self.dutoan_status.configure(text=f"Không lưu được cấu hình: {exc}", foreground="#a12622")
            return
        self.dutoan_busy = True
        self.dutoan_button.configure(state="disabled")
        self.dutoan_progress = {"text": "Đang tải…", "result": None}

        def progress(done, total):
            mb = done / (1024 * 1024)
            self.dutoan_progress["text"] = f"Đang tải… {mb:.0f}/{total / (1024 * 1024):.0f} MB" if total else f"Đang tải… {mb:.0f} MB"

        def worker():
            self.dutoan_progress["result"] = dutoan_data.download(url, sha, progress=progress)

        threading.Thread(target=worker, daemon=True).start()
        self.after(300, self.poll_dutoan_download)

    def poll_dutoan_download(self):
        result = self.dutoan_progress["result"]
        if result is None:
            self.dutoan_status.configure(text=self.dutoan_progress["text"], foreground="#225c53")
            self.after(300, self.poll_dutoan_download)
            return
        self.dutoan_busy = False
        self.dutoan_button.configure(state="normal")
        self.dutoan_status.configure(text=result["message"], foreground="#225c53" if result["ok"] else "#a12622")
        if result["ok"] and hasattr(self, "dutoan_label"):
            self.dutoan_label.configure(text="●  dutoan  ·  Sẵn sàng (HTTP qua gateway)")

    def save_dutoan_auto_setting(self):
        enabled = bool(self.dutoan_auto_var.get())
        try:
            save_setting("dutoan_auto_update", enabled)
        except OSError as exc:
            self.dutoan_auto_var.set(not enabled)
            self.dutoan_status.configure(text=f"Không lưu được cài đặt: {exc}", foreground="#a12622")
            return
        if enabled:
            self.run_dutoan_sync(manual=False)

    def dutoan_tick(self):
        """Look at the team gateway once after start and then every six hours."""
        if self.closing:
            return
        if self.dutoan_auto_var.get():
            self.run_dutoan_sync(manual=False)
        self.after(6 * 3600 * 1000, self.dutoan_tick)

    def run_dutoan_sync(self, manual):
        if self.dutoan_busy:
            return
        if manual:
            try:
                save_setting("dutoan_data_key", self.dutoan_key_var.get().strip())
            except OSError as exc:
                self.dutoan_status.configure(text=f"Không lưu được khóa: {exc}", foreground="#a12622")
                return
        settings = knowledge_propose.load_settings()
        key = dutoan_data.sync_key(settings, knowledge_propose.team_key(settings))
        if not key:
            if manual:
                self.dutoan_status.configure(text="Chưa có khóa dữ liệu dự toán nên chưa tự tải được. Nhập khóa bên dưới hoặc dùng địa chỉ tải riêng.", foreground="#a12622")
            return
        self.dutoan_busy = True
        self.dutoan_sync_button.configure(state="disabled")
        self.dutoan_progress = {"text": "Đang hỏi cổng nhóm…", "result": None, "manual": manual}
        gateway = knowledge_propose.gateway_url(settings)

        def progress(done, total):
            mb = done / (1024 * 1024)
            self.dutoan_progress["text"] = f"Đang tải… {mb:.0f}/{total / (1024 * 1024):.0f} MB" if total else f"Đang tải… {mb:.0f} MB"

        def worker():
            try:
                self.dutoan_progress["result"] = dutoan_data.sync(gateway, key, progress=progress)
            except Exception as exc:  # never leave the button disabled
                self.dutoan_progress["result"] = {"ok": False, "changed": False, "message": f"Không cập nhật được: {exc}"}

        threading.Thread(target=worker, daemon=True).start()
        self.after(300, self.poll_dutoan_sync)

    def poll_dutoan_sync(self):
        result = self.dutoan_progress["result"]
        if result is None:
            self.dutoan_status.configure(text=self.dutoan_progress["text"], foreground="#225c53")
            self.after(300, self.poll_dutoan_sync)
            return
        self.dutoan_busy = False
        self.dutoan_sync_button.configure(state="normal")
        # A quiet start-up check only speaks when something changed or went wrong with a database that is missing.
        if self.dutoan_progress.get("manual") or result.get("changed") or (not result["ok"] and not dutoan_data.describe()["present"]):
            self.dutoan_status.configure(text=result["message"], foreground="#225c53" if result["ok"] else "#a12622")
        if result["ok"] and hasattr(self, "dutoan_label"):
            self.dutoan_label.configure(text="●  dutoan  ·  Sẵn sàng (HTTP qua gateway)")

    def import_dutoan_file(self):
        if self.dutoan_busy:
            return
        chosen = filedialog.askopenfilename(
            parent=self, title="Chọn tệp dữ liệu dự toán",
            filetypes=[("Dữ liệu dự toán", "*.db *.zip"), ("Tất cả", "*.*")])
        if not chosen:
            return
        self.dutoan_busy = True
        self.dutoan_progress = {"text": "Đang nhập và kiểm tra tệp…", "result": None}

        def worker():
            try:
                self.dutoan_progress["result"] = dutoan_data.import_file(chosen)
            except Exception as exc:  # never leave the buttons blocked
                self.dutoan_progress["result"] = {"ok": False, "message": f"Không nhập được: {exc}"}

        threading.Thread(target=worker, daemon=True).start()
        self.after(300, self.poll_dutoan_download)

    def open_dutoan_folder(self):
        folder = dutoan_data.db_path().parent
        try:
            folder.mkdir(parents=True, exist_ok=True)
            os.startfile(folder)
        except OSError as exc:
            self.dutoan_status.configure(text=f"Không mở được thư mục: {exc}", foreground="#a12622")

    def save_propose_settings(self):
        url = self.propose_url_var.get().strip().rstrip("/")
        key = self.propose_key_var.get().strip() if not knowledge_propose.embedded_key() else None
        if not url.startswith("https://"):
            self.propose_status.configure(text="Địa chỉ cổng phải bắt đầu bằng https://", foreground="#a12622")
            return
        try:
            save_setting("knowledge_gateway_url", url)
            if key is not None:
                save_setting("knowledge_team_key", key)
        except OSError as exc:
            self.propose_status.configure(text=f"Không lưu được cấu hình: {exc}", foreground="#a12622")
            return
        self.propose_status.configure(
            text="Đã lưu. Agent gửi được đề xuất." if knowledge_propose.team_key() else "Đã lưu địa chỉ. Chưa có khóa nhóm nên chưa gửi được.",
            foreground="#225c53")

    def save_knowledge_auto_setting(self):
        enabled = bool(self.knowledge_auto_var.get())
        try:
            save_setting("knowledge_auto_update", enabled)
        except OSError as exc:
            self.knowledge_auto_var.set(not enabled)
            self.knowledge_status.configure(text=f"Không lưu được cài đặt: {exc}", foreground="#a12622")
            return
        if enabled:
            self.run_knowledge_check(force=False)
        else:
            self.refresh_knowledge_status("Đã tắt tự cập nhật.")

    def refresh_knowledge_status(self, note=None):
        version = knowledge.read_version(self.knowledge_dir_var.get())
        last = load_settings().get("knowledge_last_check")
        parts = [f"Tri thức {version['tag']}" if version else "Chưa tải tri thức"]
        if isinstance(last, (int, float)) and last > 0:
            parts.append("kiểm tra lần cuối " + time.strftime("%H:%M %d/%m", time.localtime(last)))
        text = "; ".join(parts) + "."
        if note:
            text += " " + note
        self.knowledge_status.configure(text=text, foreground="#225c53")

    def knowledge_tick(self):
        """Look once after start and then every hour; a look only contacts GitHub when 24 hours have passed."""
        if self.closing:
            return
        if self.knowledge_auto_var.get():
            self.run_knowledge_check(force=False)
        self.after(3600 * 1000, self.knowledge_tick)

    def run_knowledge_check(self, force):
        if self.knowledge_checking:
            return
        self.knowledge_checking = True
        destination = self.knowledge_dir_var.get()
        last_check = load_settings().get("knowledge_last_check")
        if force:
            self.knowledge_btn.configure(state="disabled")
            self.knowledge_status.configure(text="Đang tải…", foreground="#225c53")

        def worker():
            result = knowledge.check(destination, last_check=last_check if isinstance(last_check, (int, float)) else None,
                                     force=force)
            self.after(0, lambda: self.finish_knowledge_check(result))

        threading.Thread(target=worker, daemon=True).start()

    def finish_knowledge_check(self, result):
        self.knowledge_checking = False
        self.knowledge_btn.configure(state="normal")
        if result.get("checked"):
            try:
                save_setting("knowledge_last_check", time.time())
            except OSError:
                pass
        if result["state"] == "error":
            self.knowledge_status.configure(text=result["message"], foreground="#a12622")
        elif result["state"] == "unavailable":
            self.knowledge_status.configure(text=result["message"], foreground="#65736f")
        else:
            self.refresh_knowledge_status(result["message"] if result["state"] == "updated" else None)

    def refresh_config(self):
        steps = {
            "OpenAI Codex": "Thủ công: gộp các mục trong ô dưới vào cấu hình Codex, rồi mở lại Codex.",
            "Claude Code": "Thủ công: chạy các lệnh trong ô dưới, rồi mở phiên Claude Code mới.",
            "Claude Desktop": "Thủ công: gộp ô dưới vào cấu hình Claude Desktop, rồi thoát hẳn và mở lại Claude Desktop.",
            "Cursor": "Thủ công: gộp ô dưới vào cấu hình Cursor, rồi mở lại Cursor.",
        }
        self.hint.configure(text=steps[self.agent.get()])
        self.config_box.delete("1.0", "end")
        self.config_box.insert("1.0", config_for(self.agent.get()))

    def auto_configure(self, remove=False):
        """Tự thêm (hoặc gỡ) ba mục của launcher trong agent đang chọn, sau khi người dùng xác nhận."""
        if getattr(self, "agentcfg_busy", False):
            return
        agent = self.agent.get()
        ctx = agent_context()
        plan = agentconfig.describe_plan(agent, ctx, remove=remove)
        if plan["problem"]:
            self.agentcfg_status.configure(text=plan["problem"], foreground="#a12622")
            return
        if not plan["changes"]:
            self.agentcfg_status.configure(
                text="Không có gì phải đổi: " + ("chưa có mục nào của launcher." if remove else "cấu hình đã đúng sẵn."),
                foreground="#225c53")
            return
        title = "Gỡ cấu hình khỏi agent" if remove else "Tự thêm cấu hình vào agent"
        if not messagebox.askyesno(title, plan["text"] + "\n\nTiếp tục?"):
            return
        self.agentcfg_busy = True
        self.auto_btn.configure(state="disabled")
        self.unauto_btn.configure(state="disabled")
        self.agentcfg_status.configure(text="Đang ghi cấu hình…", foreground="#225c53")
        self.agentcfg_result = {"value": None}

        def worker():
            try:
                self.agentcfg_result["value"] = agentconfig.apply(agent, ctx, remove=remove)
            except Exception as exc:  # không để luồng nền chết im lặng
                self.agentcfg_result["value"] = {"ok": False, "message": f"Lỗi không mong đợi: {exc}", "backup": None, "next": ""}

        threading.Thread(target=worker, daemon=True).start()
        self.after(200, self.poll_auto_configure)

    def poll_auto_configure(self):
        result = self.agentcfg_result["value"]
        if result is None:
            self.after(200, self.poll_auto_configure)
            return
        self.agentcfg_busy = False
        self.auto_btn.configure(state="normal")
        self.unauto_btn.configure(state="normal")
        text = result["message"]
        if result.get("backup"):
            text += " Đã sao lưu bản cũ."
        if result.get("next"):
            text += " " + result["next"]
        self.agentcfg_status.configure(text=text, foreground="#225c53" if result["ok"] else "#a12622")

    def copy(self):
        self.clipboard_clear()
        self.clipboard_append(self.config_box.get("1.0", "end-1c"))
        self.status.set("Đã sao chép cấu hình")

    def on_unmap(self, event):
        if event.widget is self and self.tray:
            self.after(0, self.hide_if_iconic)

    def hide_if_iconic(self):
        if self.state() == "iconic":
            self.withdraw()

    def hide_to_tray(self):
        if self.tray:
            self.withdraw()
        else:
            self.close()

    def restore(self):
        self.deiconify()
        self.state("normal")
        self.lift()
        self.focus_force()

    def show_tray_menu(self, x, y):
        try:
            self.tray_menu.tk_popup(x, y)
        finally:
            self.tray_menu.grab_release()

    def start(self):
        if self.updating or self.busy or (self.gateway and self.gateway.poll() is None):
            return
        self.busy = True
        self.start_btn.configure(state="disabled")
        self.stop_btn.configure(state="disabled")
        self.status.set("Đang mở gateway cho agent…")
        threading.Thread(target=self.start_worker, daemon=True).start()

    def start_worker(self):
        try:
            LOG_DIR.mkdir(parents=True, exist_ok=True)
            for key, repo in REPOS.items():
                if not python_in(repo).is_file():
                    raise RuntimeError(f"Thiếu thư viện {NAMES[key]}. Thoát app rồi mở lại để cài.")
            if self.closing:
                return

            if listening(8764):
                pid = listener_pid(8764) if is_launcher_gateway() else None
                if not pid:
                    raise RuntimeError("Cổng 8764 đã được chương trình khác sử dụng")
                self.gateway = AdoptedGateway(pid)
                self.events.put(("status", "Gateway đã chạy sẵn trên cổng 8764; app dùng lại nó."))
                self._maybe_start_cadweb()
                return
            self.log = RotatingLog(LOG_DIR / "gateway.log")
            command = [str(python_in(REPOS["puran"])), str(ROOT / "launcher" / "gateway.py")]
            self.gateway = start_logged(command, self.log, cwd=ROOT)
            for _ in range(100):
                if self.gateway.poll() is not None:
                    raise RuntimeError("Gateway thoát khi khởi động; xem launcher/logs/gateway.log")
                if listening(8764):
                    break
                threading.Event().wait(0.1)
            else:
                raise RuntimeError("Gateway chưa mở cổng 8764")
            self.events.put(("status", "Gateway sẵn sàng. Agent sẽ thử AutoCAD khi gọi tool; nếu không có AutoCAD, agent sẽ hỏi bạn trước khi xuất DXF."))
            self._maybe_start_cadweb()
        except Exception as exc:
            kill_tree(self.gateway)
            self.gateway = None
            if self.log:
                self.log.close()
                self.log = None
            self.events.put(("error", str(exc)))
        finally:
            self.events.put(("ready", ""))

    def stop(self):
        kill_tree(self.gateway)
        self.gateway = None
        if self.log:
            self.log.close()
            self.log = None
        for key in REPOS:
            self.labels[key].configure(text=f"○  {NAMES[key]}  ·  Chưa khởi chạy")
        self.cadweb.stop()
        if self.cadweb_row:
            self.cadweb_label.configure(text="○  CAD Studio (local)  ·  Chưa mở")
        self.status.set("Đã dừng gateway và MCP đang hoạt động")

    def _maybe_start_cadweb(self):
        """Best-effort: tự mở CAD Studio (local) cùng gateway, nếu máy này có project và đã bật tùy chọn."""
        if not self.cadweb_row or not self.cadweb_auto_var.get():
            return
        try:
            self.cadweb.start()
        except Exception as exc:
            self.events.put(("cadweb_status", f"○  CAD Studio (local)  ·  {exc}"))
            return
        self.events.put(("cadweb_status", "●  CAD Studio (local)  ·  Đang khởi động… bấm \"Mở CAD Studio (local)\" để vào"))

    def open_cadweb_local(self):
        if self.cadweb_busy:
            return
        self.cadweb_busy = True
        self.cadweb_open_btn.configure(state="disabled")
        self.cadweb_label.configure(text="○  CAD Studio (local)  ·  Đang mở…")
        threading.Thread(target=self._open_cadweb_worker, daemon=True).start()

    def _open_cadweb_worker(self):
        try:
            self.cadweb.start()
            port = self.cadweb.wait_web()
        except Exception as exc:
            self.events.put(("cadweb_status", f"○  CAD Studio (local)  ·  {exc}"))
        else:
            if port:
                webbrowser.open(f"http://localhost:{port}")
                self.events.put(("cadweb_status", f"●  CAD Studio (local)  ·  Đang mở (http://localhost:{port})"))
            else:
                self.events.put(("cadweb_status", "○  CAD Studio (local)  ·  Chưa thấy web sẵn sàng; xem launcher/logs/cadweb-local-*.log"))
        finally:
            self.events.put(("cadweb_ready", ""))

    def save_cadweb_auto_setting(self):
        enabled = bool(self.cadweb_auto_var.get())
        try:
            save_setting("cadweb_local_auto", enabled)
        except OSError as exc:
            self.cadweb_auto_var.set(not enabled)
            messagebox.showerror("Không lưu được cài đặt", str(exc), parent=self)

    def check_for_updates(self):
        if self.closing or self.updating:
            return

        def worker():
            try:
                from updater import find_update

                update = find_update(UPDATE_REPO, app_version())
                if update:
                    self.events.put(("update_available", update))
            except Exception as exc:
                # Best-effort and quiet in the UI, but leave the reason in a log so a
                # release without its package is not invisible.
                try:
                    from logfile import RotatingLog

                    log = RotatingLog(LOG_DIR / "updater.log", max_bytes=256 * 1024, keep=1)
                    log.banner(f"update check failed: {type(exc).__name__}: {exc}")
                    log.close()
                except Exception:
                    pass

        threading.Thread(target=worker, daemon=True).start()

    def offer_update(self, update):
        self.pending_update = update
        notes = (update.get("notes") or "Không có ghi chú phát hành.").strip()
        if len(notes) > 1800:
            notes = notes[:1800].rstrip() + "…"
        message = (
            f"Đang dùng: v{app_version()}\n"
            f"Bản mới: v{update['version']}\n\n"
            f"{notes}\n\n"
            "Cập nhật sẽ khởi động lại launcher và kết nối MCP. "
            "Bạn có muốn cập nhật ngay không?"
        )
        if messagebox.askyesno("Có bản cập nhật AutoCAD MCP Launcher", message, parent=self):
            self.begin_update(update)

    def begin_update(self, update):
        if self.updating:
            return
        self.updating = True
        self.start_btn.configure(state="disabled")
        self.stop_btn.configure(state="disabled")
        self.status.set(f"Đang tải bản cập nhật v{update['version']}…")

        def worker():
            try:
                from updater import download_release

                archive = download_release(
                    update,
                    lambda received, total: self.events.put(
                        ("update_progress", received, total)
                    ),
                )
                self.events.put(("update_downloaded", str(archive)))
            except Exception as exc:
                self.events.put(("update_failed", str(exc)))

        threading.Thread(target=worker, daemon=True).start()

    def wait_for_idle_then_apply(self):
        if self.closing or not self.update_archive:
            return
        busy = False
        if self.gateway and self.gateway.poll() is None:
            try:
                with urllib.request.urlopen("http://127.0.0.1:8764/status", timeout=0.5) as response:
                    state = json.load(response)
                busy = bool(state.get("active_request") or state.get("queued_requests"))
            except (OSError, ValueError):
                busy = True
        if busy:
            self.status.set("Đang chờ các yêu cầu AutoCAD đang chạy hoàn tất trước khi cập nhật…")
            if self.update_wait_started and time.monotonic() - self.update_wait_started > 600:
                if not self.update_busy_notice_shown:
                    self.update_busy_notice_shown = True
                    proceed = messagebox.askyesno(
                        "Đang chờ MCP",
                        "MCP vẫn đang xử lý yêu cầu sau 10 phút. Tiếp tục chờ?\n"
                        "Chọn Không để dừng cập nhật và giữ launcher đang chạy.",
                        parent=self,
                    )
                    if not proceed:
                        self.updating = False
                        self.update_archive = None
                        self.start_btn.configure(state="normal")
                        self.stop_btn.configure(state="normal")
                        self.status.set("Đã hủy cập nhật; launcher vẫn hoạt động.")
                        return
                    self.update_wait_started = time.monotonic()
                    self.update_busy_notice_shown = False
            self.after(1000, self.wait_for_idle_then_apply)
            return

        self.status.set("Đang cài đặt bản mới và khởi động lại launcher…")
        try:
            updater = ROOT / "launcher" / "updater.py"
            command = [
                sys.executable,
                str(updater),
                "--apply",
                "--archive",
                str(self.update_archive),
                "--root",
                str(ROOT),
                "--parent-pid",
                str(os.getpid()),
                "--version",
                str(self.pending_update["version"]),
                "--python",
                sys.executable,
            ]
            if self.gateway and self.gateway.poll() is None:
                command.append("--start")
            subprocess.Popen(
                command,
                cwd=ROOT,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                creationflags=subprocess.CREATE_NO_WINDOW,
            )
            self.close()
        except Exception as exc:
            self.updating = False
            self.update_archive = None
            self.start_btn.configure(state="normal")
            self.stop_btn.configure(state="normal")
            self.status.set(f"Không thể chạy trình cập nhật: {exc}")

    def finish_update_download(self, archive):
        self.update_archive = Path(archive)
        self.update_wait_started = time.monotonic()
        self.status.set("Đã tải và xác minh gói cập nhật.")
        self.wait_for_idle_then_apply()

    def tick(self):
        if self.tray:
            self.tray.poll()
        try:
            while True:
                event = self.events.get_nowait()
                kind = event[0]
                value = event[1] if len(event) > 1 else None
                if kind == "status":
                    self.status.set(value)
                elif kind == "error":
                    self.status.set(value)
                    messagebox.showerror("Không thể khởi động", value)
                elif kind == "ready":
                    self.busy = False
                    self.start_btn.configure(state="normal")
                    self.stop_btn.configure(state="normal")
                elif kind == "cadweb_status":
                    if self.cadweb_row:
                        self.cadweb_label.configure(text=value)
                elif kind == "cadweb_ready":
                    self.cadweb_busy = False
                    if self.cadweb_row:
                        self.cadweb_open_btn.configure(state="normal")
                elif kind == "update_available":
                    self.offer_update(value)
                elif kind == "update_progress":
                    received, total = event[1], event[2]
                    if total:
                        self.status.set(f"Đang tải bản cập nhật… {received * 100 // total}%")
                    else:
                        self.status.set(f"Đang tải bản cập nhật… {received // (1024 * 1024)} MB")
                elif kind == "update_downloaded":
                    self.finish_update_download(value)
                elif kind == "update_failed":
                    self.updating = False
                    self.start_btn.configure(state="normal")
                    self.stop_btn.configure(state="normal")
                    self.status.set("Không tải được bản cập nhật; launcher vẫn đang chạy.")
                    messagebox.showerror("Cập nhật thất bại", value, parent=self)
        except queue.Empty:
            pass
        if self.gateway and self.gateway.poll() is None and not self.busy:
            try:
                with urllib.request.urlopen("http://127.0.0.1:8764/status", timeout=0.3) as response:
                    state = json.load(response)
                active = state["active"]
                offline = state.get("mode") == "ezdxf"
                for key in REPOS:
                    label = ("●  " if key == active else "○  ") + NAMES[key]
                    label += ("  ·  DXF offline" if offline else "  ·  Đã kết nối AutoCAD") if key == active else "  ·  Chưa khởi chạy"
                    self.labels[key].configure(text=label)
                status_text = state.get("error") or state["state"]
                waiting = int(state.get("queued_requests", 0) or 0)
                active_request = state.get("active_request")
                if active_request:
                    status_text += f" · Đang xử lý {active_request.get('tool', 'yêu cầu')}"
                if waiting:
                    status_text += f" · {waiting} yêu cầu đang chờ"
                remote_text = remote_agent.describe(state.get("remote_agent"))
                if remote_text:
                    status_text += f" · Server: {remote_text}"
                for key, label in self.pipe_labels.items():
                    label.configure(text=litebim_bridge.describe(key, state.get(key)))
                self.status.set(status_text)
                self.remote_live.configure(text="Trạng thái: " + (remote_text or "đang tắt."))
            except (OSError, ValueError, KeyError):
                pass
        self.after(500, self.tick)

    def close(self):
        self.closing = True
        self.stop()
        if self.tray:
            self.tray.close()
        self.destroy()


if __name__ == "__main__":
    try:
        from updater import migrate_beiming_rename

        migrate_beiming_rename(ROOT)
    except Exception:
        pass   # best-effort; nếu hỏng, launcher sẽ báo Beiming chưa cài và cho cài lại
    App().mainloop()
