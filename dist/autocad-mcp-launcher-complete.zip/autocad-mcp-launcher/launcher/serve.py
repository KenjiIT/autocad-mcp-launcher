"""Run one checkout as a local Streamable HTTP MCP server."""
import os
import sys
from pathlib import Path


def extends_read_timeout(repo):
    """Large-drawing reads (drawing.audit, entity.collect) need a deadline beyond 60 s.

    The Beiming source was renamed from beiming183-cloud's checkout to autocad-beiming-mcp;
    matching only the old name silently dropped the extension and poisoned the COM worker.
    """
    return repo.name.startswith("beiming183") or repo.name == "autocad-beiming-mcp"


def main():
    repo = Path(sys.argv[1]).resolve(strict=True)
    port = int(sys.argv[2])
    sys.path.insert(0, str(repo / "src"))
    os.chdir(repo)
    os.environ.setdefault("AUTOCAD_MCP_BACKEND", "file_ipc")
    adapter_root = Path(__file__).resolve().parent.parent / "lt-adapter" / "py"
    if repo.name == "autocad-beiming-mcp" and adapter_root.is_dir():
        sys.path.insert(0, str(adapter_root))
        from lt_adapter.bootstrap import install as install_lt_adapter
        install_lt_adapter()
    if repo.name.startswith("beiming183"):
        os.environ.setdefault("AUTOCAD_MCP_OUTPUT_ROOT", str(repo / "output"))
        os.environ.setdefault("AUTOCAD_MCP_AUTOSTART", "false")
    if extends_read_timeout(repo):
        from beiming_timeout import apply as apply_beiming_read_timeout
        apply_beiming_read_timeout()
    from autocad_mcp.server import mcp
    if repo.name.startswith("beiming183"):
        from beiming_batch_copy import register as register_batch_copy
        register_batch_copy(mcp)
        from beiming_region_copy import register as register_region_copy
        register_region_copy(mcp)
        from beiming_delete_batch import register as register_delete_batch
        register_delete_batch(mcp)
    mcp.settings.host = "127.0.0.1"
    mcp.settings.port = port
    mcp.settings.stateless_http = True
    mcp.run(transport="streamable-http")


if __name__ == "__main__":
    main()
