"""Abstract base class for AutoCAD backends + CommandResult envelope."""

from __future__ import annotations

import math
import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any

from autocad_mcp.errors import LayerNotFoundError, error_payload
from autocad_mcp.contracts import EntityExpectation, build_entity_expectation, compare_entity


@dataclass
class CommandResult:
    """Structured result envelope from backend operations."""

    ok: bool
    payload: Any = None
    error: str | None = None
    error_code: str | None = None
    recoverable: bool | None = None
    recommended_action: str | None = None

    def to_dict(self) -> dict:
        d: dict[str, Any] = {"ok": self.ok}
        if self.ok:
            d["payload"] = self.payload
        else:
            d["error"] = error_payload(
                self.error,
                code=self.error_code,
                recoverable=self.recoverable,
                recommended_action=self.recommended_action,
            )
            if self.payload is not None:
                d["details"] = self.payload
        return d


@dataclass
class BackendCapabilities:
    """Declares what a backend supports."""

    can_read_drawing: bool = False
    can_modify_entities: bool = False
    can_create_entities: bool = True
    can_screenshot: bool = False
    can_save: bool = False
    can_plot_pdf: bool = False
    can_zoom: bool = False
    can_query_entities: bool = False
    can_file_operations: bool = False
    can_undo: bool = False
    can_create_solids: bool = False
    can_boolean_solids: bool = False
    can_project_views: bool = False
    can_product_features: bool = False
    can_fixed_camera_views: bool = False


class AutoCADBackend(ABC):
    """Abstract interface for AutoCAD operation backends."""

    @property
    @abstractmethod
    def name(self) -> str:
        """Backend identifier: 'file_ipc' or 'ezdxf'."""

    @property
    @abstractmethod
    def capabilities(self) -> BackendCapabilities:
        """Declare supported operations."""

    @abstractmethod
    async def initialize(self) -> CommandResult:
        """Initialize the backend. Called once at startup."""

    @abstractmethod
    async def status(self) -> CommandResult:
        """Return backend health/status info."""

    async def shutdown(self) -> None:
        """Release backend-owned workers without closing the user's CAD app."""
        return None

    def _local_document_state(self) -> dict[str, Any]:
        state = getattr(self, "_document_state", None)
        if state is None:
            state = {
                "doc_id": f"{self.name}-{uuid.uuid4().hex}",
                "revision": 0,
                "path": getattr(self, "_save_path", None),
            }
            setattr(self, "_document_state", state)
        state["path"] = getattr(self, "_save_path", None) or state.get("path")
        return state

    async def document_context(self) -> CommandResult:
        state = self._local_document_state()
        return CommandResult(
            ok=True,
            payload={
                "doc_id": state["doc_id"],
                "active_doc_id": state["doc_id"],
                "requested_path": state.get("path"),
                "active_path": state.get("path"),
                "revision": int(state["revision"]),
                "backend": self.name,
            },
        )

    async def require_document_context(
        self,
        doc_id: str | None,
        expected_revision: int | None,
        lease_token: str | None = None,
        worker_generation: int | None = None,
    ) -> CommandResult:
        context = await self.document_context()
        if not context.ok:
            return context
        actual = context.payload
        if not doc_id:
            return CommandResult(
                ok=False,
                error="A modifying operation requires doc_id",
                error_code="E_PARAMETER_REJECTED",
                recommended_action="read_document_context_and_retry",
                payload={"required": ["doc_id", "expected_revision"], "actual": actual},
            )
        if str(doc_id) != str(actual["active_doc_id"]):
            return CommandResult(
                ok=False,
                error="Requested document is not the active document",
                error_code="E_DOCUMENT_ID_MISMATCH",
                recoverable=False,
                recommended_action="activate_the_requested_document_and_retry",
                payload={"requested_doc_id": doc_id, "actual": actual},
            )
        if expected_revision is None or int(expected_revision) != int(actual["revision"]):
            return CommandResult(
                ok=False,
                error="Requested document revision is stale or missing",
                error_code="E_DOCUMENT_REVISION_MISMATCH",
                recoverable=False,
                recommended_action="read_latest_document_revision_and_retry",
                payload={"expected_revision": expected_revision, "actual": actual},
            )
        return CommandResult(ok=True, payload=actual)

    async def record_document_mutation(self, doc_id: str) -> CommandResult:
        state = self._local_document_state()
        if str(doc_id) != str(state["doc_id"]):
            return CommandResult(
                ok=False,
                error="Cannot advance revision for a non-active document",
                error_code="E_DOCUMENT_ID_MISMATCH",
            )
        state["revision"] = int(state["revision"]) + 1
        return await self.document_context()

    @staticmethod
    def _validate_activation_request(
        doc_id: str | None, expected_revision: int | None
    ) -> tuple[str | None, int | None, CommandResult | None]:
        """Validate the identity fence before a backend can touch AutoCAD.

        Activation is a document-state mutation even though it does not change
        drawing geometry.  Keeping this check in the common backend interface
        prevents compatibility callers from accidentally falling back to the
        previously active document when either fence field is omitted.
        """
        if not isinstance(doc_id, str) or not doc_id.strip():
            return None, None, CommandResult(
                ok=False,
                error="drawing.activate requires a non-empty doc_id",
                error_code="E_PARAMETER_REJECTED",
                recoverable=False,
                recommended_action="read_document_context_and_retry",
                payload={"required": ["doc_id", "expected_revision"]},
            )
        if expected_revision is None or isinstance(expected_revision, bool):
            return None, None, CommandResult(
                ok=False,
                error="drawing.activate requires expected_revision",
                error_code="E_PARAMETER_REJECTED",
                recoverable=False,
                recommended_action="read_document_context_and_retry",
                payload={"required": ["doc_id", "expected_revision"]},
            )
        try:
            revision = int(expected_revision)
        except (TypeError, ValueError, OverflowError):
            return None, None, CommandResult(
                ok=False,
                error="drawing.activate expected_revision must be an integer",
                error_code="E_PARAMETER_REJECTED",
                recoverable=False,
                recommended_action="read_document_context_and_retry",
                payload={"expected_revision": expected_revision},
            )
        if isinstance(expected_revision, float) and not expected_revision.is_integer():
            return None, None, CommandResult(
                ok=False,
                error="drawing.activate expected_revision must be an integer",
                error_code="E_PARAMETER_REJECTED",
                recoverable=False,
                recommended_action="read_document_context_and_retry",
                payload={"expected_revision": expected_revision},
            )
        if revision < 0:
            return None, None, CommandResult(
                ok=False,
                error="drawing.activate expected_revision must be non-negative",
                error_code="E_PARAMETER_REJECTED",
                recoverable=False,
                recommended_action="read_document_context_and_retry",
                payload={"expected_revision": expected_revision},
            )
        return doc_id.strip(), revision, None

    async def drawing_activate(
        self,
        doc_id: str | None,
        expected_revision: int | None = None,
        lease_token: str | None = None,
        worker_generation: int | None = None,
    ) -> CommandResult:
        del lease_token, worker_generation
        normalized_doc_id, _, validation = self._validate_activation_request(
            doc_id, expected_revision
        )
        if validation is not None:
            return validation
        context = await self.document_context()
        if context.ok and context.payload["doc_id"] == normalized_doc_id:
            if int(context.payload.get("revision", -1)) == int(expected_revision):
                return context
            return CommandResult(
                ok=False,
                error="Requested document revision is stale",
                error_code="E_DOCUMENT_REVISION_MISMATCH",
                recoverable=False,
                recommended_action="read_latest_document_revision_and_retry",
                payload={
                    "requested_doc_id": normalized_doc_id,
                    "expected_revision": expected_revision,
                    "actual": context.payload,
                },
            )
        return CommandResult(
            ok=False,
            error="Document activation is not supported on this backend",
            error_code="E_DOCUMENT_ACTIVATION_UNSUPPORTED",
        )

    async def transaction_begin(
        self, doc_id: str, expected_revision: int
    ) -> CommandResult:
        return CommandResult(ok=False, error="Transactions are not supported on this backend")

    async def transaction_commit(
        self, transaction_id: str, doc_id: str, expected_revision: int
    ) -> CommandResult:
        return CommandResult(ok=False, error="Transactions are not supported on this backend")

    async def transaction_rollback(
        self, transaction_id: str, doc_id: str, expected_revision: int
    ) -> CommandResult:
        return CommandResult(ok=False, error="Transactions are not supported on this backend")

    # --- Drawing management ---

    async def drawing_info(self) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def drawing_save(self, path: str | None = None) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def drawing_copy_dwg(self, path: str) -> CommandResult:
        return CommandResult(ok=False, error="Read-only DWG copy is not supported on this backend")

    async def drawing_save_as_dxf(self, path: str) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def drawing_create(
        self, name: str | None = None, idempotency_key: str | None = None
    ) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def native_transaction_execute(
        self,
        doc_id: str,
        expected_revision: int,
        idempotency_key: str,
        operations: list[dict[str, Any]],
        *,
        session_id: str | None = None,
    ) -> CommandResult:
        return CommandResult(
            ok=False,
            error="The native transactional worker is not available on this backend",
            error_code="E_NATIVE_PLUGIN_UNAVAILABLE",
            recoverable=False,
        )

    async def drawing_close(self, save: bool = False) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def apply_presentation_style(
        self, colors: dict[str, list[int] | tuple[int, int, int]], visual_style: str
    ) -> CommandResult:
        return CommandResult(ok=False, error="Presentation styling is not supported")

    async def drawing_purge(self) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def drawing_plot_pdf(
        self,
        path: str,
        paper: str = "A3",
        orientation: str = "landscape",
        plot_style: str = "monochrome.ctb",
        scale_mode: str = "fit",
        scale: str = "fit",
        center: bool = True,
    ) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def drawing_render_preview(
        self,
        path: str,
        paper: str = "A4",
        orientation: str = "auto",
        plot_style: str = "monochrome.ctb",
        dpi: int = 150,
        force: bool = True,
        background: str = "white",
        plot_type: str = "extents",
        normalize_framing: bool = False,
        framing_fill: float = 0.82,
        visual_style: str | None = None,
        preserve_visual_style: bool = True,
    ) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def prepare_recording_view(
        self,
        bounds: dict[str, list[float]],
        view: str = "iso",
        margin_scale: float = 0.82,
        output_aspect: float = 16 / 9,
    ) -> CommandResult:
        return CommandResult(ok=False, error="Recording view preparation is not supported")

    async def drawing_audit(
        self,
        limit: int = 50,
        include_entities: bool = True,
        changed_only: bool = False,
        layer: str | None = None,
        space: str = "model",
        rules: dict[str, Any] | None = None,
    ) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def drawing_audit_dxf(
        self, path: str, limit: int = 50, include_entities: bool = True
    ) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def drawing_get_variables(self, names: list[str] | None = None) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def drawing_set_variables(self, values: dict[str, Any]) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def drawing_open(self, path: str) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def drawing_setup_mechanical(self, config: dict[str, Any] | None = None) -> CommandResult:
        """Create the standard monochrome mechanical-drafting layers."""
        from autocad_mcp.drafting import MECHANICAL_LAYERS
        from autocad_mcp.variables import mechanical_variable_updates

        results = []
        for layer in MECHANICAL_LAYERS:
            result = await self.layer_create(**layer)
            results.append(result.to_dict())
            if not result.ok:
                return CommandResult(ok=False, payload={"layers": results}, error=result.error)
        try:
            updates = mechanical_variable_updates(config)
        except ValueError as exc:
            return CommandResult(ok=False, error=str(exc), error_code="E_VARIABLE_REJECTED")
        variables = await self.drawing_set_variables(updates)
        if not variables.ok:
            return variables
        options = dict(config or {})
        return CommandResult(
            ok=True,
            payload={
                "profile": "mechanical-gbt",
                "standard": options.get("standard", "GB/T"),
                "units": options.get("units", "mm"),
                "sheet": options.get("sheet", "A3"),
                "orientation": options.get("orientation", "landscape"),
                "projection": options.get("projection", "first-angle"),
                "scale": options.get("scale", "1:1"),
                "layers": results,
                "variables": variables.payload,
            },
        )

    async def recover(self) -> CommandResult:
        return CommandResult(ok=False, error="Recovery is not supported on this backend")

    # --- Undo / Redo ---

    async def undo(self) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def redo(self) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    # --- Freehand LISP execution ---

    async def execute_lisp(self, code: str) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    # --- Entity operations ---

    async def create_line(self, x1: float, y1: float, x2: float, y2: float, layer: str | None = None) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def create_circle(self, cx: float, cy: float, radius: float, layer: str | None = None) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def create_polyline(self, points: list[list[float]], closed: bool = False, layer: str | None = None) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def create_rectangle(self, x1: float, y1: float, x2: float, y2: float, layer: str | None = None) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def create_arc(self, cx: float, cy: float, radius: float, start_angle: float, end_angle: float, layer: str | None = None) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def create_ellipse(self, cx: float, cy: float, major_x: float, major_y: float, ratio: float, layer: str | None = None) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def create_mtext(self, x: float, y: float, width: float, text: str, height: float = 2.5, layer: str | None = None) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def create_hatch(
        self,
        entity_id: str,
        pattern: str = "ANSI31",
        angle: float = 0.0,
        scale: float = 1.0,
        layer: str | None = None,
    ) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def create_batch(
        self,
        entities: list[dict[str, Any]],
        continue_on_error: bool = False,
        atomic: bool = False,
        strict: bool = True,
    ) -> CommandResult:
        """Create a bounded structured entity batch without arbitrary code execution."""
        if len(entities) > 500:
            return CommandResult(ok=False, error="A batch is limited to 500 entities")

        results: list[dict[str, Any]] = []
        last_handle: str | None = None
        created_handles: list[str] = []
        failures = 0
        for index, item in enumerate(entities):
            kind = str(item.get("type", "")).lower()
            layer = item.get("layer")
            expectation: EntityExpectation | None = None
            try:
                if kind != "hatch":
                    expectation = build_entity_expectation(
                        kind,
                        {key: value for key, value in item.items() if key not in {"type", "layer"}},
                        layer=layer,
                        strict=strict,
                    )
                if kind == "line":
                    result = await self.create_line(
                        item["x1"], item["y1"], item["x2"], item["y2"], layer
                    )
                elif kind == "circle":
                    result = await self.create_circle(
                        item["cx"], item["cy"], item["radius"], layer
                    )
                elif kind == "polyline":
                    result = await self.create_polyline(
                        item["points"], item.get("closed", False), layer
                    )
                elif kind == "rectangle":
                    result = await self.create_rectangle(
                        item["x1"], item["y1"], item["x2"], item["y2"], layer
                    )
                elif kind == "arc":
                    result = await self.create_arc(
                        item["cx"],
                        item["cy"],
                        item["radius"],
                        item["start_angle"],
                        item["end_angle"],
                        layer,
                    )
                elif kind == "ellipse":
                    result = await self.create_ellipse(
                        item["cx"],
                        item["cy"],
                        item["major_x"],
                        item["major_y"],
                        item["ratio"],
                        layer,
                    )
                elif kind == "text":
                    result = await self.create_text(
                        item["x"],
                        item["y"],
                        item["text"],
                        item.get("height", 2.5),
                        item.get("rotation", 0.0),
                        layer,
                    )
                elif kind == "mtext":
                    result = await self.create_mtext(
                        item["x"],
                        item["y"],
                        item["width"],
                        item["text"],
                        item.get("height", 2.5),
                        layer,
                    )
                elif kind == "hatch":
                    entity_id = item.get("entity_id")
                    if entity_id in (None, "last", "$last"):
                        entity_id = last_handle or "last"
                    pattern = str(item.get("pattern", "ANSI31"))
                    angle = float(item.get("angle", 0.0))
                    scale = float(item.get("scale", 1.0))
                    if not pattern.strip():
                        raise ValueError("hatch pattern must not be empty")
                    if not math.isfinite(angle):
                        raise ValueError("hatch angle must be finite")
                    if not math.isfinite(scale) or scale <= 0:
                        raise ValueError("hatch scale must be positive")
                    result = await self.create_hatch(
                        entity_id,
                        pattern,
                        angle,
                        scale,
                        layer,
                    )
                    result = await self.verify_created_hatch(
                        result,
                        entity_id=str(entity_id),
                        pattern=pattern,
                        angle=angle,
                        scale=scale,
                        layer=layer,
                    )
                else:
                    result = CommandResult(ok=False, error=f"Unsupported batch type: {kind}")
                if expectation is not None:
                    result = await self.verify_created_entity(expectation, result)
            except LayerNotFoundError as exc:
                result = CommandResult(
                    ok=False,
                    error=str(exc),
                    error_code="E_LAYER_NOT_FOUND",
                    recoverable=False,
                    recommended_action="create_or_select_an_existing_layer",
                    payload={"layer": layer, "entity_created": False},
                )
            except (KeyError, TypeError, ValueError) as exc:
                result = CommandResult(
                    ok=False,
                    error=f"Invalid {kind or 'entity'}: {exc}",
                    error_code="E_PARAMETER_REJECTED",
                )

            entry = {"index": index, "type": kind, **result.to_dict()}
            results.append(entry)
            if result.ok and isinstance(result.payload, dict):
                last_handle = result.payload.get("handle", last_handle)
                if result.payload.get("handle"):
                    created_handles.append(str(result.payload["handle"]))
                created_handles.extend(str(handle) for handle in result.payload.get("handles", []))
            if not result.ok:
                failures += 1
                if not continue_on_error:
                    break

        rolled_back: list[str] = []
        rollback_errors: list[dict[str, str]] = []
        if failures and atomic:
            for handle in reversed(created_handles):
                rollback = await self.entity_erase(handle)
                if rollback.ok:
                    rolled_back.append(handle)
                else:
                    rollback_errors.append({"handle": handle, "error": rollback.error or "unknown"})

        payload = {
                "batch_ok": failures == 0,
                "requested": len(entities),
                "processed": len(results),
                "failures": failures,
                "results": results,
                "atomic": bool(atomic),
                "created_handles": created_handles,
                "rolled_back": rolled_back,
                "rollback_errors": rollback_errors,
            }
        return CommandResult(
            ok=failures == 0,
            payload=payload,
            error=(f"Batch failed after {len(results)} operations" if failures else None),
            error_code=("E_BATCH_ROLLED_BACK" if failures and atomic else "E_BATCH_FAILED")
            if failures
            else None,
        )

    async def verify_created_entity(
        self,
        expectation: EntityExpectation,
        result: CommandResult,
        *,
        tolerance: float = 0.000001,
    ) -> CommandResult:
        """Read back a created entity and remove it if its postcondition is false."""
        if not result.ok or not isinstance(result.payload, dict):
            return result
        handle = result.payload.get("handle")
        if not handle:
            return CommandResult(
                ok=False,
                error="Entity creation returned no handle for postcondition verification",
                error_code="E_POSTCONDITION_MISMATCH",
                payload={
                    "requested": expectation.requested(),
                    "actual": None,
                    "diff": [{"path": "handle", "requested": "created handle", "actual": None}],
                    "deleted": False,
                },
            )

        readback = await self.entity_get(str(handle))
        actual = readback.payload if readback.ok and isinstance(readback.payload, dict) else None
        differences = (
            compare_entity(expectation, actual, tolerance=tolerance)
            if actual is not None
            else [{"path": "entity_get", "requested": "readable entity", "actual": readback.error}]
        )
        if differences:
            deletion = await self.entity_erase(str(handle))
            self._semantic_store().pop(str(handle), None)
            return CommandResult(
                ok=False,
                error=f"Created entity {handle} did not match its immutable request",
                error_code="E_POSTCONDITION_MISMATCH",
                recoverable=False,
                recommended_action="stop_and_inspect_backend_state",
                payload={
                    "handle": str(handle),
                    "requested": expectation.requested(),
                    "actual": actual,
                    "diff": differences,
                    "deleted": deletion.ok,
                    "delete_error": deletion.error,
                },
            )

        semantics = expectation.semantic_dict()
        if semantics:
            self._semantic_store()[str(handle)] = semantics
            actual = {**actual, "semantics": semantics}
        return CommandResult(
            ok=True,
            payload={
                **result.payload,
                "verified": True,
                "layer": actual.get("layer"),
                "bounds": actual.get("bounds"),
                "volume": actual.get("volume"),
                "requested": expectation.requested(),
                "actual": actual,
                "diff": [],
            },
        )

    async def verify_created_hatch(
        self,
        result: CommandResult,
        *,
        entity_id: str,
        pattern: str,
        angle: float,
        scale: float,
        layer: str | None = None,
        boundary_area: float | None = None,
        boundary_bounds: dict[str, Any] | None = None,
        tolerance: float = 0.000001,
    ) -> CommandResult:
        """Read back a HATCH and erase it when its contract is not true.

        HATCH is intentionally kept separate from ``EntityExpectation``: its
        boundary is an existing entity, while the created object still has a
        strict type/layer/pattern/angle/scale postcondition.
        """
        if not result.ok or not isinstance(result.payload, dict):
            return result
        handle = result.payload.get("handle")
        requested_layer = str(layer or "0")
        is_solid = str(pattern).casefold() == "solid"
        requested = {
            "type": "HATCH",
            "layer": requested_layer,
            "pattern": str(pattern),
            "angle": float(angle),
            "scale": float(scale),
            "boundary_entity_id": str(entity_id),
        }
        if not handle:
            return CommandResult(
                ok=False,
                error="HATCH creation returned no handle for postcondition verification",
                error_code="E_POSTCONDITION_MISMATCH",
                recoverable=False,
                payload={
                    "requested": requested,
                    "actual": None,
                    "diff": [{"path": "handle", "requested": "created handle", "actual": None}],
                    "deleted": False,
                },
            )

        readback = await self.entity_get(str(handle))
        actual = readback.payload if readback.ok and isinstance(readback.payload, dict) else None
        differences: list[dict[str, Any]] = []
        if actual is None:
            differences.append(
                {"path": "entity_get", "requested": "readable HATCH", "actual": readback.error}
            )
        else:
            if str(actual.get("type", "")).upper() != "HATCH":
                differences.append({"path": "type", "requested": "HATCH", "actual": actual.get("type")})
            if str(actual.get("layer", "")).casefold() != requested_layer.casefold():
                differences.append({"path": "layer", "requested": requested_layer, "actual": actual.get("layer")})
            if str(actual.get("pattern", "")).casefold() != str(pattern).casefold():
                differences.append({"path": "pattern", "requested": str(pattern), "actual": actual.get("pattern")})
            dimensional_checks = []
            if not is_solid:
                dimensional_checks.extend((("angle", float(angle)), ("scale", float(scale))))
            for field, expected in dimensional_checks:
                value = actual.get(field)
                try:
                    actual_number = float(value)
                except (TypeError, ValueError):
                    differences.append({"path": field, "requested": expected, "actual": value})
                    continue
                if not math.isfinite(actual_number):
                    differences.append({"path": field, "requested": expected, "actual": value})
                    continue
                delta = actual_number - expected
                if field == "angle":
                    delta = (delta + 180.0) % 360.0 - 180.0
                if abs(delta) > tolerance:
                    differences.append(
                        {
                            "path": field,
                            "requested": expected,
                            "actual": actual_number,
                            "delta": delta,
                            "tolerance": tolerance,
                        }
                    )
            if boundary_area is not None:
                try:
                    expected_area = float(boundary_area)
                    actual_area = float(actual.get("area"))
                except (TypeError, ValueError):
                    expected_area = float(boundary_area)
                    actual_area = math.nan
                area_tolerance = max(tolerance, abs(expected_area) * 1e-8)
                if not math.isfinite(actual_area) or abs(actual_area - expected_area) > area_tolerance:
                    differences.append(
                        {
                            "path": "area",
                            "requested": expected_area,
                            "actual": actual.get("area"),
                            "tolerance": area_tolerance,
                        }
                    )
            if boundary_bounds is not None:
                actual_bounds = actual.get("bounds")
                bound_tolerance = tolerance
                try:
                    expected_min = [float(value) for value in boundary_bounds["min"][:3]]
                    expected_max = [float(value) for value in boundary_bounds["max"][:3]]
                    actual_min = [float(value) for value in actual_bounds["min"][:3]]
                    actual_max = [float(value) for value in actual_bounds["max"][:3]]
                    coordinate_scale = max(1.0, *(abs(value) for value in expected_min + expected_max))
                    bound_tolerance = max(tolerance, coordinate_scale * 1e-9)
                    if len(expected_min) != 3 or len(expected_max) != 3 or len(actual_min) != 3 or len(actual_max) != 3:
                        raise ValueError("incomplete bounds")
                    for endpoint, expected_values, actual_values in (
                        ("min", expected_min, actual_min),
                        ("max", expected_max, actual_max),
                    ):
                        for axis, expected_value, actual_value in zip(("x", "y", "z"), expected_values, actual_values):
                            if not math.isfinite(actual_value) or abs(actual_value - expected_value) > bound_tolerance:
                                differences.append(
                                    {
                                        "path": f"bounds.{endpoint}.{axis}",
                                        "requested": expected_value,
                                        "actual": actual_value,
                                        "tolerance": bound_tolerance,
                                    }
                                )
                except (KeyError, TypeError, ValueError):
                    differences.append(
                        {
                            "path": "bounds",
                            "requested": boundary_bounds,
                            "actual": actual_bounds,
                            "tolerance": bound_tolerance,
                        }
                    )
        if differences:
            deletion = await self.entity_erase(str(handle))
            self._semantic_store().pop(str(handle), None)
            return CommandResult(
                ok=False,
                error=f"Created HATCH {handle} did not match its immutable request",
                error_code="E_POSTCONDITION_MISMATCH",
                recoverable=False,
                recommended_action="stop_and_inspect_backend_state",
                payload={
                    "handle": str(handle),
                    "requested": requested,
                    "actual": actual,
                    "diff": differences,
                    "deleted": deletion.ok,
                    "delete_error": deletion.error,
                },
            )
        return CommandResult(
            ok=True,
            payload={
                **result.payload,
                "verified": True,
                "requested": requested,
                "actual": actual,
                "diff": [],
                "layer": actual.get("layer") if actual else requested_layer,
                "bounds": actual.get("bounds") if actual else None,
                "volume": actual.get("volume") if actual else None,
            },
        )

    def _semantic_store(self) -> dict[str, dict[str, Any]]:
        store = getattr(self, "_entity_semantics", None)
        if store is None:
            store = {}
            setattr(self, "_entity_semantics", store)
        return store

    async def entity_get_with_semantics(self, entity_id: str) -> CommandResult:
        result = await self.entity_get(entity_id)
        if result.ok and isinstance(result.payload, dict):
            semantics = self._semantic_store().get(str(entity_id))
            if semantics:
                result.payload = {**result.payload, "semantics": dict(semantics)}
        return result

    async def entity_list(self, layer: str | None = None) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def entity_count(self, layer: str | None = None) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def entity_get(self, entity_id: str) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def entity_erase(self, entity_id: str) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def entity_copy(self, entity_id: str, dx: float, dy: float) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def entity_move(self, entity_id: str, dx: float, dy: float) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def entity_rotate(self, entity_id: str, cx: float, cy: float, angle: float) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def entity_scale(self, entity_id: str, cx: float, cy: float, factor: float) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def entity_mirror(self, entity_id: str, x1: float, y1: float, x2: float, y2: float) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def entity_offset(self, entity_id: str, distance: float) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def entity_array(self, entity_id: str, rows: int, cols: int, row_dist: float, col_dist: float) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def entity_fillet(self, entity_id1: str, entity_id2: str, radius: float) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def entity_chamfer(self, entity_id1: str, entity_id2: str, dist1: float, dist2: float) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def entity_trim(self, cutters: list[str], targets: list[dict[str, Any]]) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def entity_extend(self, boundaries: list[str], targets: list[dict[str, Any]]) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def entity_break(
        self, entity_id: str, point1: list[float], point2: list[float]
    ) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def entity_join(self, entity_ids: list[str], tolerance: float = 0.0) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def entity_constrain(
        self, constraint: str, entity_ids: list[str]
    ) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    # --- Native 3D solid operations ---

    async def solid_create_box(
        self, center: list[float], length: float, width: float, height: float, layer: str | None = None
    ) -> CommandResult:
        return CommandResult(ok=False, error="3D solids are not supported on this backend")

    async def solid_create_cylinder(
        self, base_center: list[float], radius: float, height: float, layer: str | None = None
    ) -> CommandResult:
        return CommandResult(ok=False, error="3D solids are not supported on this backend")

    async def solid_extrude(
        self,
        profile_id: str,
        height: float,
        taper_angle: float = 0.0,
        erase_profile: bool = False,
        layer: str | None = None,
    ) -> CommandResult:
        return CommandResult(ok=False, error="3D solids are not supported on this backend")

    async def solid_revolve(
        self,
        profile_id: str,
        axis_point: list[float],
        axis_direction: list[float],
        angle: float = 360.0,
        erase_profile: bool = False,
        layer: str | None = None,
    ) -> CommandResult:
        return CommandResult(ok=False, error="3D solids are not supported on this backend")

    async def solid_sweep(
        self,
        profile_id: str,
        path_id: str,
        erase_profile: bool = False,
        layer: str | None = None,
    ) -> CommandResult:
        return CommandResult(ok=False, error="3D solids are not supported on this backend")

    async def solid_boolean(
        self, primary_id: str, tool_id: str, operation: str
    ) -> CommandResult:
        return CommandResult(ok=False, error="3D solid booleans are not supported on this backend")

    # --- Industrial product features and evidence ---

    async def product_create_feature(
        self, kind: str, data: dict[str, Any]
    ) -> CommandResult:
        return CommandResult(
            ok=False,
            error="Parametric product features are not supported on this backend",
            error_code="E_UNSUPPORTED_OPERATION",
        )

    async def product_render_view(
        self, view_name: str, path: str, options: dict[str, Any] | None = None
    ) -> CommandResult:
        return CommandResult(
            ok=False,
            error="Fixed-camera product views are not supported on this backend",
            error_code="E_UNSUPPORTED_OPERATION",
        )

    async def solid_fillet_edges(
        self, entity_id: str, semantic_roles: list[str], radius: float
    ) -> CommandResult:
        return CommandResult(
            ok=False,
            error="Stable native B-rep edge selection is unavailable",
            error_code="E_STABLE_FEATURE_SELECTION_UNAVAILABLE",
            recoverable=False,
            recommended_action="use_an_analytic_parametric_feature_or_a_native_feature_plugin",
        )

    async def solid_chamfer_edges(
        self, entity_id: str, semantic_roles: list[str], distance: float
    ) -> CommandResult:
        return CommandResult(
            ok=False,
            error="Stable native B-rep edge selection is unavailable",
            error_code="E_STABLE_FEATURE_SELECTION_UNAVAILABLE",
            recoverable=False,
            recommended_action="use_an_analytic_parametric_feature_or_a_native_feature_plugin",
        )

    # --- Layer operations ---

    async def layer_list(self) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def layer_exists(self, name: str) -> CommandResult:
        listing = await self.layer_list()
        if not listing.ok:
            return listing
        layers = listing.payload.get("layers", []) if isinstance(listing.payload, dict) else []
        names = {
            str(layer.get("name") if isinstance(layer, dict) else layer).casefold()
            for layer in layers
        }
        return CommandResult(ok=True, payload={"name": name, "exists": name.casefold() in names})

    async def layer_create(
        self,
        name: str,
        color: str | int = "white",
        linetype: str = "CONTINUOUS",
        lineweight: str | float | int | None = None,
    ) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def layer_set_current(self, name: str) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def layer_set_properties(self, name: str, color: str | int | None = None, linetype: str | None = None, lineweight: str | None = None) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def layer_freeze(self, name: str) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def layer_thaw(self, name: str) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def layer_lock(self, name: str) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def layer_unlock(self, name: str) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    # --- Block operations ---

    async def block_list(self) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def block_insert(self, name: str, x: float, y: float, scale: float = 1.0, rotation: float = 0.0, block_id: str | None = None) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def block_insert_with_attributes(self, name: str, x: float, y: float, scale: float = 1.0, rotation: float = 0.0, attributes: dict[str, str] | None = None) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def block_get_attributes(self, entity_id: str) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def block_update_attribute(self, entity_id: str, tag: str, value: str) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def block_define(self, name: str, entities: list[dict]) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    # --- Annotation ---

    async def create_text(self, x: float, y: float, text: str, height: float = 2.5, rotation: float = 0.0, layer: str | None = None) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def create_dimension_linear(self, x1: float, y1: float, x2: float, y2: float, dim_x: float, dim_y: float) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def create_dimension_aligned(self, x1: float, y1: float, x2: float, y2: float, offset: float) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def create_dimension_angular(self, cx: float, cy: float, x1: float, y1: float, x2: float, y2: float) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def create_dimension_radius(self, cx: float, cy: float, radius: float, angle: float) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def create_leader(self, points: list[list[float]], text: str) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    # --- P&ID ---

    async def pid_setup_layers(self) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def pid_insert_symbol(self, category: str, symbol: str, x: float, y: float, scale: float = 1.0, rotation: float = 0.0) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def pid_list_symbols(self, category: str) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def pid_draw_process_line(self, x1: float, y1: float, x2: float, y2: float) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def pid_connect_equipment(self, x1: float, y1: float, x2: float, y2: float) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def pid_add_flow_arrow(self, x: float, y: float, rotation: float = 0.0) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def pid_add_equipment_tag(self, x: float, y: float, tag: str, description: str = "") -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def pid_add_line_number(self, x: float, y: float, line_num: str, spec: str) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def pid_insert_valve(self, x: float, y: float, valve_type: str, rotation: float = 0.0, attributes: dict[str, str] | None = None) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def pid_insert_instrument(self, x: float, y: float, instrument_type: str, rotation: float = 0.0, tag_id: str = "", range_value: str = "") -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def pid_insert_pump(self, x: float, y: float, pump_type: str, rotation: float = 0.0, attributes: dict[str, str] | None = None) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def pid_insert_tank(self, x: float, y: float, tank_type: str, scale: float = 1.0, attributes: dict[str, str] | None = None) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    # --- View ---

    async def zoom_extents(self) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def zoom_window(self, x1: float, y1: float, x2: float, y2: float) -> CommandResult:
        return CommandResult(ok=False, error="Not supported on this backend")

    async def show_window(self, activate: bool = True) -> CommandResult:
        return CommandResult(ok=False, error="Window display is not supported on this backend")

    async def minimize_window(self) -> CommandResult:
        return CommandResult(ok=False, error="Window display is not supported on this backend")

    async def get_screenshot(self) -> CommandResult:
        """Return base64 PNG in payload."""
        return CommandResult(ok=False, error="Not supported on this backend")
